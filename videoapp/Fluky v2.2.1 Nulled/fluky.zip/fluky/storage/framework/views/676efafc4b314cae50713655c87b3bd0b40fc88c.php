<body>
	<p>Hi <?php echo e($username); ?>, your plan has expired! </p>

    <p>Click <a href="<?php echo e(Request::root()); ?>/pricing">here</a> to renew now.</p>

    <p>Thank you!</p>
</body>
<?php /**PATH C:\xampp\htdocs\fluky\fluky_2.0.0_9_8_13_08\resources\views/emails/plan.blade.php ENDPATH**/ ?>