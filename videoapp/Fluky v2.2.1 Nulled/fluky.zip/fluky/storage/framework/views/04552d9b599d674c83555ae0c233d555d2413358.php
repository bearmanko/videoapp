<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" dir="<?php echo e(getSelectedLanguage()->direction); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Styles -->
    <style type="text/css">
        :root {
            --primary-color: <?php echo e(getSetting('THEME_COLOR')); ?>;
        }

    </style>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/fa.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/ionicons.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/responsive.bootstrap4.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/toastr.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/admin.css')); ?>" rel="stylesheet">

    <link rel="icon" type="image/png" href="<?php echo e(asset('storage/images/FAVICON.png')); ?>">
    <?php echo $__env->yieldContent('style'); ?>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">
        <!-- Navbar -->
        <nav class="main-header navbar navbar-expand navbar-white navbar-light">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="<?php echo e(__('Toggle navigation')); ?>">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Left Side Of Navbar -->
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i
                            class="fas fa-bars"></i></a>
                </li>
            </ul>

            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ml-auto">
                <?php if(getLanguages()->count() > 1): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fa fa-globe"></i> <?php echo e(getSelectedLanguage()->name); ?>

                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <?php $__currentLoopData = getLanguages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="dropdown-item <?php if(getSelectedLanguage()->name == $language->name): ?> active <?php endif; ?>"
                                    href="<?php echo e(route('language', ['locale' => $language->code])); ?>"><?php echo e($language->name); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </li>
                <?php endif; ?>

                <!-- Authentication Links -->
                <?php if(auth()->guard()->guest()): ?>
                    <?php if(Route::has('login')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                        </li>
                    <?php endif; ?>

                    <?php if(Route::has('register')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                        </li>
                    <?php endif; ?>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link active" href="<?php echo e(route('admin')); ?>"><?php echo e(__('Admin')); ?></a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a>
                    </li>

                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <?php echo e(Auth::user()->username); ?>

                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo e(route('changePassword')); ?>">
                                <?php echo e(__('Change Password')); ?>

                            </a>

                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                                                                                 document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <aside class="main-sidebar sidebar-dark-primary elevation-4">
            <!-- Brand Logo -->
            <a href="<?php echo e(route('admin')); ?>" class="brand-link d-flex justify-content-center">
                <span class="letter-set"><?php echo e(getSetting('APPLICATION_NAME')[0]); ?></span>
                <img src="<?php echo e(asset('storage/images/LOGO.png')); ?>" alt="<?php echo e(getSetting('APPLICATION_NAME')); ?>">
            </a>

            <!-- Sidebar -->
            <div class="sidebar">
                <!-- Sidebar Menu -->
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                        data-accordion="false">
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin')); ?>" class="nav-link" data-name="admin">
                                <i class="nav-icon fas fa-tachometer-alt"></i>
                                <p>
                                    <?php echo e(__('Dashboard')); ?>

                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('users')); ?>" class="nav-link" data-name="users">
                                <i class="nav-icon fa fa-users"></i>
                                <p>
                                    <?php echo e(__('Users')); ?>

                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('reportedUsers')); ?>" class="nav-link" data-name="reported-users">
                                <i class="nav-icon fa fa-flag"></i>
                                <p>
                                    <?php echo e(__('Reported Users')); ?>

                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('bannedUsers')); ?>" class="nav-link" data-name="banned-users">
                                <i class="nav-icon fa fa-ban"></i>
                                <p>
                                    <?php echo e(__('Banned Users')); ?>

                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('income')); ?>" class="nav-link" data-name="income">
                                <i class="nav-icon fa fa-dollar-sign"></i>
                                <p>
                                    <?php echo e(__('Income')); ?>

                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('global-config')); ?>" class="nav-link" data-name="global-config">
                                <i class="nav-icon fa fa-cog"></i>
                                <p>
                                    <?php echo e(__('Global Configuration')); ?>

                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('languages')); ?>" class="nav-link" data-name="languages">
                                <i class="nav-icon fa fa-language"></i>
                                <p>
                                    <?php echo e(__('Languages')); ?>

                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('features')); ?>" class="nav-link" data-name="features">
                                <i class="nav-icon fa fa-sliders-h"></i>
                                <p>
                                    <?php echo e(__('Features')); ?>

                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('signaling')); ?>" class="nav-link" data-name="signaling">
                                <i class="nav-icon fa fa-signal"></i>
                                <p>
                                    <?php echo e(__('Signaling Server')); ?>

                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('pages')); ?>" class="nav-link" data-name="pages">
                                <i class="nav-icon fa fa-file-alt"></i>
                                <p>
                                    <?php echo e(__('Pages')); ?>

                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('update')); ?>" class="nav-link" data-name="update">
                                <i class="nav-icon fa fa-download"></i>
                                <p>
                                    <?php echo e(__('Manage Update')); ?>

                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('license')); ?>" class="nav-link" data-name="license">
                                <i class="nav-icon fa fa-id-badge"></i>
                                <p>
                                    <?php echo e(__('Manage License')); ?>

                                </p>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-sm-6">
                            <h1 class="m-0"><?php echo $__env->yieldContent('page'); ?></h1>
                        </div><!-- /.col -->
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>"><?php echo e(__('Home')); ?></a>
                                </li>
                                <li class="breadcrumb-item active"><?php echo $__env->yieldContent('page'); ?></li>
                            </ol>
                        </div><!-- /.col -->
                    </div><!-- /.row -->
                </div><!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </section>
        </div>
        <!-- /.content-wrapper -->

        <footer class="main-footer">
            <strong><?php echo e(__('Copyright')); ?> &copy; <?php echo e(date('Y')); ?>

                <?php echo e(getSetting('APPLICATION_NAME')); ?>.</strong>
            <?php echo e(__('All rights reserved')); ?>

            <div class="float-right d-none d-sm-inline-block">
                <b><?php echo e(__('Version')); ?></b> <?php echo e(getSetting('VERSION')); ?>

            </div>
        </footer>
    </div>

    <!-- Scripts -->
    <script>
        const languages = {
            error_occurred: "<?php echo e(__('An error occurred, please try again')); ?>",
            data_updated: "<?php echo e(__('Data updated successfully')); ?>",
            valid_license: "<?php echo e(__('Your license is valid. Type: ')); ?>",
            invalid_license: "<?php echo e(__('Your license is invalid. Error: ')); ?>",
            confirmation: "<?php echo e(__('Are you sure')); ?>",
            license_uninstalled: "<?php echo e(__('License uninstalled')); ?>",
            license_uninstalled_failed: "<?php echo e(__('License uninstallation failed. Error: ')); ?>",
            update_available: "<?php echo e(__('An update is available: Version: ')); ?>",
            already_latest_version: "<?php echo e(__('Application is already at latest version. Version: ')); ?>",
            application_updated: "<?php echo e(__('The application has been successfully updated to the latest version')); ?>",
            update_failed: "<?php echo e(__('Update failed. Error: ')); ?>",
            user_ignored: "<?php echo e(__('The user has been ignored')); ?>",
            user_banned: "<?php echo e(__('The user has been banned')); ?>",
            user_unbanned: "<?php echo e(__('The user has been unbanned')); ?>",
            select_record: "<?php echo e(__('Please select at least one record')); ?>",
            data_added: "<?php echo e(__('Data added successfully')); ?>",
            data_deleted: "<?php echo e(__('The language has been deleted')); ?>",
            income: "<?php echo e(__('Income')); ?>",
            user_registration: "<?php echo e(__('User Registration')); ?>",
            jan: "<?php echo e(__('Jan')); ?>",
            feb: "<?php echo e(__('Feb')); ?>",
            mar: "<?php echo e(__('Mar')); ?>",
            apr: "<?php echo e(__('Apr')); ?>",
            may: "<?php echo e(__('May')); ?>",
            june: "<?php echo e(__('June')); ?>",
            jul: "<?php echo e(__('Jul')); ?>",
            aug: "<?php echo e(__('Aug')); ?>",
            sep: "<?php echo e(__('Sep')); ?>",
            oct: "<?php echo e(__('Oct')); ?>",
            nov: "<?php echo e(__('Nov')); ?>",
            dec: "<?php echo e(__('Dec')); ?>",
            free: "<?php echo e(__('Free')); ?>",
            paid: "<?php echo e(__('Paid')); ?>",
            male: "<?php echo e(__('Male')); ?>",
            female: "<?php echo e(__('Female')); ?>",
            info: "<?php echo e(__('Showing page _PAGE_ of _PAGES_')); ?>",
            lengthMenu: "<?php echo e(__('Display _MENU_ records per page')); ?>",
            zeroRecords: "<?php echo e(__('Nothing found - sorry')); ?>",
            infoEmpty: "<?php echo e(__('No records available')); ?>",
            infoFiltered: "<?php echo e(__('filtered from _MAX_ total records')); ?>",
            next: "<?php echo e(__('Next')); ?>",
            previous: "<?php echo e(__('Previous')); ?>",
            search: "<?php echo e(__('Search')); ?>",
        };
    </script>
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/app.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/toastr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/common.js')); ?>"></script>
    <?php echo $__env->yieldContent('script'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\fluky\fluky_2.2.0\resources\views/layouts/admin.blade.php ENDPATH**/ ?>