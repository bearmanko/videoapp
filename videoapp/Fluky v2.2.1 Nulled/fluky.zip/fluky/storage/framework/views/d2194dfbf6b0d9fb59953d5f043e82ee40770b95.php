<?php $__env->startSection('page', $page); ?>
<?php $__env->startSection('title', getSetting('APPLICATION_NAME') . ' | ' . $page); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-6 col-lg-6 pl-4 pr-4">
      <div class="card">
        <!-- <div class="card-header"><?php echo e(__('Change Password')); ?></div> -->

        <div class="card-body auth-section">
          <form id="changePasswordEdit">
            <div class="row">
              <div class="col-12 text-center">
                <i class="fa fa-lock change-password-icon"></i>
              </div>
            </div>
            <div class="form-group row">
              <div class="col-md-12 p-0">
                <input type="password" name="current" class="form-control" placeholder="Enter Current Password" maxlength="50" required>
                <span class="focus-border"></span>
              </div>
            </div>
            <div class="row form-group">
              <div class="col-md-12 p-0">
                <input type="password" name="new" class="form-control" placeholder="Enter New Password" maxlength="50" required>
                <span class="focus-border"></span>
              </div>
            </div>
            <div class="row form-group">
              <div class="col-md-12 p-0">
                  <input type="password" name="confirm" class="form-control" placeholder="Confirm New Password" maxlength="50" required>
                  <span class="focus-border"></span>
              </div>
            </div>
            <div class="form-group row mt-4">
              <div class="col-md-12 p-0">
                <button type="submit" id="save" class="btn btn-theme w-100 btn-lg">Save</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fluky_2.0.0_9_8\resources\views/change-password/index.blade.php ENDPATH**/ ?>