<?php $__env->startSection('page', $page); ?>
<?php $__env->startSection('title', getSetting('APPLICATION_NAME') . ' | ' . $page); ?>

<?php $__env->startSection('content'); ?>
	<div class="container-fluid text-center">
		<h3><?php echo e($page); ?></h3>
		<div class="col-12 col-md-10 mt-3 offset-md-1 text-justify">
	    	<?php echo getContent('TERMS_AND_CONDITIONS'); ?>

	    </div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fluky\fluky_2.0.0\resources\views/terms-and-conditions.blade.php ENDPATH**/ ?>