<?php $__env->startSection('page', $page); ?>
<?php $__env->startSection('title', getSetting('APPLICATION_NAME') . ' | ' . $page); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <?php if(getSetting('PAYMENT_MODE') == 'disabled'): ?>
                <span class="badge badge-warning p-2 mb-3">The payment mode is disabled, <a
                        href="<?php echo e($paymentModeLink); ?>">enable</a> now to make the features paid.</span>
            <?php endif; ?>
            <table id="features" class="table table-bordered table-striped table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Status</th>
                        <th>Paid</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($value->id); ?></td>
                            <td><?php echo e($value->title); ?></td>
                            <td><?php echo e($value->description); ?></td>
                            <td>
                                <div class="custom-control custom-switch">
                                    <input type="checkbox" class="custom-control-input feature-status"
                                        data-id="<?php echo e($value->id); ?>" id="customSwitch<?php echo e($value->id . 'status'); ?>"
                                        <?php echo e($value->status == 'active' ? 'checked' : ''); ?>>
                                    <label class="custom-control-label"
                                        for="customSwitch<?php echo e($value->id . 'status'); ?>"></label>
                                </div>
                            </td>
                            <td>
                                <?php if($value->title == 'FAKE_VIDEO'): ?>
                                    <span>-</span>
                                <?php else: ?>
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input feature-paid"
                                            data-id="<?php echo e($value->id); ?>" id="customSwitch<?php echo e($value->id . 'paid'); ?>"
                                            <?php echo e($value->paid == 'yes' ? 'checked' : ''); ?>>
                                        <label class="custom-control-label"
                                            for="customSwitch<?php echo e($value->id . 'paid'); ?>"></label>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Status</th>
                        <th>Paid</th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fluky\fluky_2.0.3\resources\views/admin/features.blade.php ENDPATH**/ ?>