<?php $__env->startSection('page', $page); ?>
<?php $__env->startSection('title', getSetting('APPLICATION_NAME') . ' | ' . $page); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form id="languagesAdd">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label><?php echo e(__('Code')); ?></label>
                            <input type="text" id="code" placeholder="<?php echo e(__('Code')); ?>" class="form-control"
                                maxlength="64" autofocus required>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label><?php echo e(__('Name')); ?></label>
                            <input type="text" id="name" placeholder="<?php echo e(__('Name')); ?>" class="form-control"
                                maxlength="255" required>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label><?php echo e(__('Direction')); ?></label>
                            <select id="direction" class="form-control">
                                <option value="ltr"><?php echo e(__('LTR')); ?></option>
                                <option value="rtl"><?php echo e(__('RTL')); ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label><?php echo e(__('Default')); ?></label>
                            <select id="default" class="form-control">
                                <option value="no"><?php echo e(__('No')); ?></option>
                                <option value="yes"><?php echo e(__('Yes')); ?></option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label><?php echo e(__('Status')); ?></label>
                            <select id="status" class="form-control">
                                <option value="active"><?php echo e(__('Active')); ?></option>
                                <option value="inactive"><?php echo e(__('Inactive')); ?></option>
                            </select>
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="form-group">
                            <label><?php echo e(__('File')); ?></label>
                            <input type="file" id="file" class="form-control" accept=".json" required>
                        </div>
                    </div>
                </div>

                <button type="submit" id="save" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                <a href="<?php echo e(route('languages')); ?>"><button type="button"
                        class="btn btn-default"><?php echo e(__('Back')); ?></button></a>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fluky\fluky_2.1.0\resources\views/admin/language/create.blade.php ENDPATH**/ ?>